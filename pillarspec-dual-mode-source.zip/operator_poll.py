"""Local monitor/bridge client. Never print credentials or customer/owner content."""
import argparse
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

ROOT=Path(__file__).resolve().parent
BASE='https://pillarspec-whatsapp-agent.fly.dev'


def credentials():
    values={}
    for name in ('.env.meta.local','.env.owner.local'):
        path=ROOT/name
        if path.exists():
            values.update(dict(line.split('=',1) for line in path.read_text(encoding='utf-8-sig').splitlines() if '=' in line and not line.startswith('#')))
    return values


def request(path,token=None,body=None):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    req=urllib.request.Request(BASE+path,data=json.dumps(body).encode() if body is not None else None,
        headers={**({'Authorization':'Bearer '+token} if token else {}),'Content-Type':'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=15) as response:
            return response.status,json.load(response)
    except urllib.error.HTTPError as exc:return exc.code,{}
    except Exception:return None,{}


def poll():
    values=credentials();statepath=ROOT/'data/operator-monitor.json';statepath.parent.mkdir(exist_ok=True)
    previous=json.loads(statepath.read_text()) if statepath.exists() else {}
    health,_=request('/ready');status,ops=request('/api/ops',values.get('REVIEWER_TOKEN'))
    healthy=health==200 and status==200
    ids=sorted(row['id_hash'] for row in ops.get('review_needed',[]))
    failures={key:value for key,value in ops.get('outbox',{}).items() if key in ('uncertain','window_closed','failed')}
    owner_failures={key:value for key,value in ops.get('owner',{}).get('states',{}).items() if key in ('uncertain','failed','manual_review')}
    events=[]
    if healthy!=previous.get('healthy',True):events.append('Service recovered' if healthy else 'Service or protected operations check failed')
    added=set(ids)-set(previous.get('review_ids',[]))
    if added:events.append(str(len(added))+' new customer inquiries need human review')
    if failures!=previous.get('failures',{}) and failures:events.append('Customer sending requires operator attention')
    if owner_failures!=previous.get('owner_failures',{}) and owner_failures:events.append('Private owner processing requires attention')
    backup=ROOT/'outputs/backup-evidence.json'
    age=int(time.time())-json.loads(backup.read_text()).get('checked_at',0) if backup.exists() else None
    stale=age is None or age>26*3600
    if stale and not previous.get('backup_stale',False):events.append('Encrypted backup is missing or more than 26 hours old')
    snapshot={'healthy':healthy,'review_ids':ids,'failures':failures,'owner_failures':owner_failures,'backup_stale':stale,'checked_at':int(time.time())}
    statepath.write_text(json.dumps(snapshot))
    tasks=[]
    if values.get('OWNER_BRIDGE_TOKEN'):
        _,response=request('/api/owner/bridge',values['OWNER_BRIDGE_TOKEN']);tasks=response.get('tasks',[])
    print(json.dumps({'events':events,'healthy':healthy,'review_pending':len(ids),
        'backup_due':age is None or age>24*3600,'pending_bridge_tasks':tasks,
        'bridge_account':'hammoudk895@gmail.com','bridge_local_only':True}))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--complete',type=Path);args=parser.parse_args()
    if args.complete:
        result=json.loads(args.complete.read_text(encoding='utf-8'))
        token=credentials().get('OWNER_BRIDGE_TOKEN')
        if not token:raise SystemExit('Bridge is not configured')
        status,_=request('/api/owner/bridge',token,{'id':result['id'],'reply':result['reply']})
        print(json.dumps({'completion_queued':status==200,'http':status}))
        raise SystemExit(0 if status==200 else 1)
    poll()


if __name__=='__main__':main()
