"""Explicit read-only account commands; executed by the authorized Codex bridge."""
import json
import time

import jarvis
import owner_security

KINDS = {'/mail': 'mail', '/calendar': 'calendar', '/drive': 'drive'}


def schema(db):
    db.execute('''CREATE TABLE IF NOT EXISTS bridge_tasks(id TEXT PRIMARY KEY, kind TEXT NOT NULL,
        query TEXT NOT NULL, created INTEGER NOT NULL, state TEXT NOT NULL)''')


def command(text):
    parts = text.strip().split(maxsplit=1)
    if not parts or parts[0].lower() not in KINDS:
        return None
    return KINDS[parts[0].lower()], parts[1].strip()[:1000] if len(parts) == 2 else ''


def enqueue(db, row):
    parsed = command(row['text'])
    if parsed is None:
        return None
    if not owner_security.unlocked():
        return 'For private email, calendar or document access, unlock with your owner key and authenticator at https://pillarspec-whatsapp-agent.fly.dev/owner . Then send your command again. No account information has been accessed.'
    kind, query = parsed
    if not query:
        return 'Add a specific read-only query after /mail, /calendar or /drive. Sending messages and changing records require a separate approval.'
    with db:
        schema(db)
        db.execute("INSERT OR IGNORE INTO bridge_tasks VALUES(?,?,?,?,'pending')", (row['id'], kind, query, int(time.time())))
        db.execute("UPDATE requests SET state='waiting_bridge' WHERE id=?", (row['id'],))
    return False


def pending():
    if not owner_security.unlocked():
        return []
    db = jarvis.connect()
    try:
        with db:
            schema(db)
        now = int(time.time())
        return [dict(row) for row in db.execute('''SELECT t.id,t.kind,t.query,t.created FROM bridge_tasks t
            JOIN requests r ON r.id=t.id WHERE t.state='pending' AND r.state='waiting_bridge'
            AND r.sender=? AND t.created>? AND r.timestamp>? ORDER BY t.created LIMIT 3''',
            (jarvis.owner(), now-1800, now-86340))]
    finally:
        db.close()


def complete(mid, reply):
    if not owner_security.unlocked() or not isinstance(mid, str) or not isinstance(reply, str) or not 0 < len(reply) <= 3500:
        raise ValueError('invalid_or_locked_bridge_result')
    db = jarvis.connect()
    try:
        db.execute('BEGIN IMMEDIATE')
        schema(db)
        row = db.execute('''SELECT t.id FROM bridge_tasks t JOIN requests r ON r.id=t.id
            WHERE t.id=? AND t.state='pending' AND r.state='waiting_bridge' AND r.sender=? AND t.created>?''',
            (mid, jarvis.owner(), int(time.time())-1800)).fetchone()
        if not row:
            raise ValueError('stale_bridge_task')
        db.execute("UPDATE bridge_tasks SET state='completed' WHERE id=?", (mid,))
        db.execute("UPDATE requests SET state='bridge_ready',reply=? WHERE id=?", ('Private business account result:\n' + reply, mid))
        db.commit()
    finally:
        db.close()
