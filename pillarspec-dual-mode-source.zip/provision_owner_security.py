"""Provision only user-verified owner credentials, via stdin; never print values."""
from pathlib import Path
import subprocess
import json

root=Path(__file__).resolve().parent
path=root/'.env.owner.local'
if not path.exists():raise SystemExit('Authenticator enrollment has not been completed.')
values=dict(line.split('=',1) for line in path.read_text().splitlines() if '=' in line)
keys=('OWNER_TOTP_SECRET','OWNER_CONTROL_TOKEN','OWNER_BRIDGE_TOKEN')
if any(len(values.get(k,''))<32 for k in keys):raise SystemExit('Incomplete owner enrollment.')
result=subprocess.run([str(root/'.tools/fly/bin/flyctl.exe'),'secrets','import','--stage','--app','pillarspec-whatsapp-agent'],
    input=''.join(k+'='+values[k]+'\n' for k in keys),capture_output=True,text=True)
print(json.dumps({'owner_credentials_staged':result.returncode==0,'credential_values_exposed':False}))
raise SystemExit(result.returncode)
