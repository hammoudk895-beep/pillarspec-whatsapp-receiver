import json
import hashlib
import hmac
import io
import os
import tempfile
import time
import unittest
from unittest.mock import patch

import jarvis
import production


class OwnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {'STATE_DIR': self.temp.name,
            'OWNER_WHATSAPP_NUMBER': '96176868315', 'SEND_ENABLED': 'true'})
        self.env.start()
        self.now = int(time.time())

    def tearDown(self):
        self.env.stop()
        self.temp.cleanup()

    def message(self, mid='owner-test', sender='96176868315'):
        return {'id': mid, 'from': sender, 'type': 'text', 'timestamp': str(self.now),
                'text': {'body': 'Research my private question'}}

    def rows(self):
        db = jarvis.connect()
        try:
            return [dict(r) for r in db.execute('SELECT * FROM requests')]
        finally:
            db.close()

    def test_private_routing_requires_exact_sender_and_account_phone(self):
        db = production.connect()
        try:
            payload = {'object': 'whatsapp_business_account', 'entry': [{'id': 'wrong', 'changes': [
                {'field': 'messages', 'value': {'metadata': {'phone_number_id': production.PHONE},
                    'messages': [self.message()]}}]}]}
            production.ingest(db, payload, self.now)
            self.assertEqual(self.rows(), [])
            payload['entry'][0]['id'] = '1842772363415623'
            production.ingest(db, payload, self.now)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM inbox').fetchone()[0], 0)
            self.assertEqual(len(self.rows()), 1)
            self.assertFalse(jarvis.accept(self.message(sender='96170000000'), self.now))
            payload['entry'][0]['changes'][0]['value']['messages'] = [self.message(mid='customer', sender='96170000000')]
            production.ingest(db, payload, self.now)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM inbox').fetchone()[0], 1)
            self.assertEqual(len(self.rows()), 1)
        finally:
            db.close()

    def test_private_history_dedup_and_single_send(self):
        jarvis.accept(self.message(), self.now)
        jarvis.accept(self.message(), self.now)
        calls = []
        def transport(*args):
            calls.append(args)
            jarvis.status({'id': 'meta-owner', 'status': 'delivered', 'biz_opaque_callback_data': args[2]})
            return 'meta-owner'
        histories = []
        def generate(text, history):
            histories.append(history)
            return 'Private reply'
        jarvis.tick(transport, generate)
        jarvis.tick(transport, generate)
        self.assertEqual(len(calls), 1)
        self.assertEqual(histories, [[]])
        self.assertEqual(self.rows()[0]['delivery'], 'delivered')
        jarvis.accept(self.message(mid='second'), self.now)
        jarvis.tick(transport, generate)
        self.assertEqual(len(histories[1]), 2)

    def test_timeout_restart_and_revocation_never_resend(self):
        jarvis.accept(self.message(), self.now)
        calls = []
        def timeout(*args):
            calls.append(args)
            raise TimeoutError()
        jarvis.tick(timeout, lambda *_: 'Answer')
        jarvis.recover_and_purge(recover=True)
        jarvis.tick(timeout, lambda *_: 'Answer')
        self.assertEqual(len(calls), 1)
        self.assertEqual(self.rows()[0]['state'], 'uncertain')
        jarvis.accept(self.message(mid='revoked'), self.now)
        with patch.dict(os.environ, {'OWNER_WHATSAPP_NUMBER': '96170000000'}):
            jarvis.tick(timeout, lambda *_: self.fail('Revoked owner reached model'))
        self.assertEqual(self.rows()[1]['state'], 'held')

    def test_expired_malformed_and_provider_failure_are_held(self):
        msg = self.message()
        msg['timestamp'] = str(self.now - 86400)
        jarvis.accept(msg, self.now)
        jarvis.tick(lambda *_: self.fail('Expired send'), lambda *_: self.fail('Expired model'))
        self.assertEqual(self.rows()[0]['state'], 'held')
        msg = self.message(mid='malformed')
        msg['timestamp'] = 'bad'
        jarvis.accept(msg, self.now)
        self.assertEqual(self.rows()[1]['state'], 'manual_review')
        jarvis.accept(self.message(mid='failed'), self.now)
        def failure(*_):
            raise RuntimeError('private provider detail')
        jarvis.tick(lambda *_: self.fail('Failed send'), failure)
        self.assertEqual(self.rows()[2]['state'], 'failed')

    def test_customer_timestamp_cannot_poison_whole_envelope(self):
        db = production.connect()
        try:
            msg = self.message(sender='96170000000')
            msg['timestamp'] = 'bad'
            payload = {'object': 'whatsapp_business_account', 'entry': [{'id': '1842772363415623', 'changes': [
                {'field': 'messages', 'value': {'metadata': {'phone_number_id': production.PHONE},
                    'messages': [msg, self.message(mid='valid', sender='96170000001')]}}]}]}
            self.assertEqual(production.ingest(db, payload, self.now), 2)
            self.assertEqual(db.execute("SELECT state FROM inbox WHERE id='valid'").fetchone()[0], 'pending')
        finally:
            db.close()

    def test_signed_webhook_to_private_delivery_and_review_isolation(self):
        payload = {'object': 'whatsapp_business_account', 'entry': [{'id': '1842772363415623', 'changes': [
            {'field': 'messages', 'value': {'metadata': {'phone_number_id': production.PHONE},
                'messages': [self.message()]}}]}]}
        raw = json.dumps(payload).encode()
        env = {'REQUEST_METHOD': 'POST', 'PATH_INFO': '/webhook', 'CONTENT_LENGTH': str(len(raw)),
               'wsgi.input': io.BytesIO(raw), 'HTTP_X_HUB_SIGNATURE_256': 'bad'}
        response = []
        with patch.dict(os.environ, {'META_APP_SECRET': 'secret', 'REVIEWER_TOKEN': 'review'}):
            production.App()(env, lambda status, _: response.append(status))
            self.assertTrue(response[-1].startswith('401'))
            self.assertEqual(self.rows(), [])
            env['wsgi.input'] = io.BytesIO(raw)
            env['HTTP_X_HUB_SIGNATURE_256'] = 'sha256=' + hmac.new(b'secret', raw, hashlib.sha256).hexdigest()
            production.App()(env, lambda status, _: response.append(status))
            self.assertTrue(response[-1].startswith('200'))
            jarvis.tick(lambda *_: 'meta-owner', lambda *_: 'Private research result')
            jarvis.status({'id': 'meta-owner', 'status': 'delivered'})
            env = {'REQUEST_METHOD': 'GET', 'PATH_INFO': '/api/review', 'HTTP_AUTHORIZATION': 'Bearer review'}
            result = b''.join(production.App()(env, lambda status, _: response.append(status)))
            self.assertEqual(json.loads(result)['messages'], [])
            ops = jarvis.operations()
            self.assertEqual(ops['delivery'], {'delivered': 1})
            self.assertNotIn('Private', json.dumps(ops))
