# Eight-service catalog package

Operator: PillarSpec S.A.R.L. Artwork: GreenPower MENA. Original images are preserved without alteration.

Seven descriptions retain previously approved source wording. The new Bunker Survey description is limited to the supplied service title and visible fuel-sampling activity; measurements, testing and scope require assignment-specific confirmation.

No prices, accreditations, operating territories or availability are inferred. Publication to Meta remains unverified.

## Bunker Survey

Survey of marine bunker fuel, including representative fuel sampling. Specific measurements, testing requirements and reporting scope are confirmed for each assignment.

Artwork: catalogue\artwork\bunker-survey.png

## Loss Control

Investigation and reconciliation of quantity discrepancies during petroleum cargo movements, including ship/shore comparisons, transfer losses and measurement analysis.

Artwork: catalogue\artwork\loss-control.png

## Tank & Terminal Inspection

Inspection and verification of petroleum storage and transfer operations, including tank measurements, quantity determination, inventory reconciliation and terminal operations.

Artwork: catalogue\artwork\tank-terminal-inspection.png

## Ship-to-Ship (STS) Cargo Inspection

Independent inspection and monitoring of ship-to-ship petroleum cargo transfers, including quantity measurements, sampling, transfer monitoring and cargo reconciliation.

Artwork: catalogue\artwork\ship-to-ship-cargo-inspection.png

## Loading & Discharge Supervision

Independent supervision of petroleum cargo loading and discharge operations, including quantity measurements, sampling, documentation and coordination between vessel, terminal and cargo interests.

Artwork: catalogue\artwork\loading-discharge-supervision.png

## Petroleum Cargo Inspection

Independent inspection of petroleum cargoes including crude oil and refined petroleum products throughout loading, discharge and transfer operations.

Artwork: catalogue\artwork\petroleum-cargo-inspection.png

## Petroleum Quantity Inspection

Independent quantity inspection of petroleum products during loading, discharge and cargo transfer operations. Includes quantity determination, measurements, reconciliation and professional inspection reporting.

Artwork: catalogue\artwork\petroleum-quantity-inspection.png

## Petroleum Quality Inspection

Independent quality inspection and representative sampling of petroleum products. Sampling, specification verification and coordination with accredited laboratories where required.

Artwork: catalogue\artwork\petroleum-quality-inspection.png
