"""Encrypted off-provider SQLite backups, with an isolated restore/integrity test."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import shlex
import sqlite3
import subprocess
import tempfile
import time
import zipfile

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = Path(__file__).resolve().parent
FLY = ROOT / '.tools/fly/bin/flyctl.exe'
STORE = ROOT / '.private-backups'


def remote(source):
    command = 'python -c ' + shlex.quote('import base64;exec(base64.b64decode(' + repr(base64.b64encode(source.encode()).decode()) + '))')
    result = subprocess.run([str(FLY), 'ssh', 'console', '--app', 'pillarspec-whatsapp-agent', '--command', command],
                            capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError('backup_remote_failed')
    return result.stdout


def main():
    os.umask(0o077)
    STORE.mkdir(exist_ok=True)
    keypath = STORE / 'recovery.key'
    if not keypath.exists():
        with keypath.open('xb') as file:
            file.write(AESGCM.generate_key(bit_length=256))
    key = keypath.read_bytes()
    source = '''import hashlib,json,os,pathlib,sqlite3,tempfile,zipfile
directory=pathlib.Path(tempfile.mkdtemp(prefix='pillarspec-backup-'))
os.chmod(directory,0o700)
manifest={}
for name in ('production.sqlite3','owner.sqlite3'):
 source=sqlite3.connect('file:/data/'+name+'?mode=ro',uri=True)
 target=sqlite3.connect(directory/name)
 source.backup(target)
 assert target.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 target.close();source.close()
 manifest[name]=hashlib.sha256((directory/name).read_bytes()).hexdigest()
with zipfile.ZipFile(directory/'state.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for name in manifest:archive.write(directory/name,name)
 archive.writestr('manifest.json',json.dumps(manifest))
for name in manifest:(directory/name).unlink()
print('BACKUP_PATH='+str(directory/'state.zip'))
'''
    output = remote(source)
    path = next((line.split('=',1)[1] for line in output.splitlines() if line.startswith('BACKUP_PATH=')), None)
    if not path or not path.startswith('/tmp/pillarspec-backup-') or not path.endswith('/state.zip'):
        raise RuntimeError('invalid_remote_backup_path')
    try:
        with tempfile.TemporaryDirectory(dir=STORE) as temp:
            local = Path(temp) / 'state.zip'
            result = subprocess.run([str(FLY),'ssh','sftp','get',path,str(local),'--app','pillarspec-whatsapp-agent'],
                                    capture_output=True,text=True)
            if result.returncode:
                raise RuntimeError('backup_download_failed')
            raw = local.read_bytes()
            nonce = os.urandom(12)
            encrypted = b'PSB1' + nonce + AESGCM(key).encrypt(nonce,raw,b'PillarSpec backup v1')
            destination = STORE / (time.strftime('%Y%m%d-%H%M%S',time.gmtime()) + '.enc')
            destination.write_bytes(encrypted)
            restored = AESGCM(key).decrypt(encrypted[4:16],encrypted[16:],b'PillarSpec backup v1')
            assert hashlib.sha256(raw).digest() == hashlib.sha256(restored).digest()
            # Restore only into a disposable local directory; never overwrite live databases.
            from io import BytesIO
            with zipfile.ZipFile(BytesIO(restored)) as archive:
                manifest = json.loads(archive.read('manifest.json'))
                for name in ('production.sqlite3','owner.sqlite3'):
                    blob = archive.read(name)
                    assert hashlib.sha256(blob).hexdigest() == manifest[name]
                    restore = Path(temp)/name
                    restore.write_bytes(blob)
                    db=sqlite3.connect(restore)
                    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
                    db.close()
            evidence={'checked_at':int(time.time()),'encrypted_backup':destination.name,'databases':2,
                      'restore_integrity_verified':True,'live_data_modified':False,
                      'encrypted_sha256':hashlib.sha256(encrypted).hexdigest()}
            (ROOT/'outputs/backup-evidence.json').write_text(json.dumps(evidence,indent=2))
            print(json.dumps(evidence))
    finally:
        remote('from pathlib import Path\np=Path('+repr(path)+')\nassert str(p).startswith("/tmp/pillarspec-backup-") and p.name=="state.zip"\np.unlink(missing_ok=True)\np.parent.rmdir()')


if __name__=='__main__':
    main()
