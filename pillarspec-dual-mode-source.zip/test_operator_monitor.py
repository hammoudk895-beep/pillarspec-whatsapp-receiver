import contextlib
import io
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import operator_poll


class MonitorTests(unittest.TestCase):
    def test_new_review_failure_and_recovery_alert_once(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'outputs').mkdir()
            (root/'outputs/backup-evidence.json').write_text(json.dumps({'checked_at':int(time.time())}))
            ops={'review_needed':[],'outbox':{},'owner':{'states':{}}}
            healthy=True
            def request(path,*_):
                return (200 if healthy else None,ops if path=='/api/ops' else {})
            def poll():
                output=io.StringIO()
                with contextlib.redirect_stdout(output):operator_poll.poll()
                return json.loads(output.getvalue())
            with patch.object(operator_poll,'ROOT',root),patch.object(operator_poll,'credentials',return_value={'REVIEWER_TOKEN':'test'}),patch.object(operator_poll,'request',side_effect=request):
                self.assertEqual(poll()['events'],[])
                ops['review_needed']=[{'id_hash':'hash','state':'manual_review','received':1}]
                self.assertEqual(len(poll()['events']),1)
                self.assertEqual(poll()['events'],[])
                healthy=False
                self.assertIn('failed',poll()['events'][0])
                self.assertEqual(poll()['events'],[])
                healthy=True
                self.assertIn('recovered',poll()['events'][0])
