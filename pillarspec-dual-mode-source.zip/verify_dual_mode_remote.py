"""Verify deployed code in an isolated temporary DB, using a stub WhatsApp transport."""
import base64
import json
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parent
tests = (ROOT / 'test_jarvis.py').read_text()
tests += '\n' + (ROOT / 'test_owner_security.py').read_text()
script = '''import hashlib, json, os, pathlib, tempfile, time, unittest
import jarvis, production, owner_security
evidence = {'owner_configuration_matches': jarvis.owner() == '96176868315',
    'owner_step_up_configured': owner_security.configured(),
    'deployed_sha256': {name: hashlib.sha256(pathlib.Path('/app/' + name).read_bytes()).hexdigest()
                        for name in ('jarvis.py', 'production.py', 'owner_security.py', 'owner_bridge.py')},
    'real_whatsapp_messages_sent': 0}
'''
script += tests + '''
suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(OwnerTests),
    unittest.defaultTestLoader.loadTestsFromTestCase(SecurityTests)])
result = unittest.TextTestRunner(verbosity=0).run(suite)
evidence['isolation_tests_passed'] = result.wasSuccessful()
evidence['isolation_test_count'] = result.testsRun
with tempfile.TemporaryDirectory() as directory:
    os.environ['STATE_DIR'] = directory
    os.environ['OWNER_WHATSAPP_NUMBER'] = '96170000000'
    now = int(time.time())
    jarvis.accept({'id': 'isolated-deployed-model-check', 'from': '96170000000', 'type': 'text',
        'timestamp': str(now), 'text': {'body': 'Search NASA for why Mars is red. Cite an HTTPS source.'}}, now)
    captured = []
    def transport(recipient, body, correlation):
        captured.append(body)
        return 'synthetic-meta-id'
    jarvis.tick(transport)
    jarvis.status({'id': 'synthetic-meta-id', 'status': 'delivered'})
    evidence['live_model_private_workflow'] = len(captured) == 1 and 'https://' in captured[0]
    evidence['isolated_delivery_reconciliation'] = jarvis.operations()['delivery'] == {'delivered': 1}
    db = production.connect()
    evidence['customer_queue_empty'] = db.execute('SELECT COUNT(*) FROM inbox').fetchone()[0] == 0
    db.close()
print('SAFE_EVIDENCE=' + json.dumps(evidence))
raise SystemExit(0 if all(evidence[k] for k in ('owner_configuration_matches','isolation_tests_passed',
    'live_model_private_workflow','isolated_delivery_reconciliation','customer_queue_empty')) else 1)
'''
encoded = base64.b64encode(script.encode()).decode()
command = 'python -c ' + shlex.quote("import base64;exec(base64.b64decode('" + encoded + "'))")
result = subprocess.run([str(ROOT / '.tools/fly/bin/flyctl.exe'), 'ssh', 'console', '--app',
    'pillarspec-whatsapp-agent', '--command', command], capture_output=True, text=True)
line = next((line.split('SAFE_EVIDENCE=', 1)[1] for line in result.stdout.splitlines() if line.startswith('SAFE_EVIDENCE=')), None)
if line:
    evidence = json.loads(line)
    evidence['local_code_matches_deployment'] = all(
        evidence['deployed_sha256'][name] == __import__('hashlib').sha256((ROOT/name).read_bytes()).hexdigest()
        for name in ('jarvis.py','production.py','owner_security.py','owner_bridge.py'))
    (ROOT / 'outputs/dual-mode-remote-evidence.json').write_text(json.dumps(evidence, indent=2))
    print(json.dumps(evidence))
else:
    print(json.dumps({'remote_verification_failed': True, 'exit_code': result.returncode}))
raise SystemExit(result.returncode)
