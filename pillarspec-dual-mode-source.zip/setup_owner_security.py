"""User-only authenticator enrollment. Secrets stay in a local dialog and ignored file."""
import base64
import os
from pathlib import Path
import secrets
import time
import tkinter as tk
from tkinter import messagebox

from owner_security import code

ROOT = Path(__file__).resolve().parent
TARGET = ROOT / '.env.owner.local'


def main():
    window=tk.Tk()
    window.title('PillarSpec — private owner security setup')
    window.geometry('760x530')
    values={}
    if TARGET.exists():
        values=dict(line.split('=',1) for line in TARGET.read_text().splitlines() if '=' in line)
    for key in ('OWNER_CONTROL_TOKEN','OWNER_BRIDGE_TOKEN'):
        values.setdefault(key,secrets.token_urlsafe(36))
    values.setdefault('OWNER_TOTP_SECRET',base64.b32encode(secrets.token_bytes(20)).decode().rstrip('='))
    tk.Label(window,text='Add PillarSpec Jarvis to your authenticator using this setup key.',wraplength=700).pack(pady=(20,8))
    secret=tk.Entry(window,width=64,show='●');secret.insert(0,values['OWNER_TOTP_SECRET']);secret.pack(pady=5)
    def reveal():secret.configure(show='' if secret.cget('show') else '●')
    tk.Button(window,text='Show / hide setup key',command=reveal).pack()
    tk.Label(window,text='Save this separate owner access key in your password manager.\nUse it with your authenticator at the private owner unlock page.',wraplength=700).pack(pady=(20,5))
    control=tk.Entry(window,width=72,show='●');control.insert(0,values['OWNER_CONTROL_TOKEN']);control.pack(pady=5)
    tk.Button(window,text='Show / hide owner access key',command=lambda:control.configure(show='' if control.cget('show') else '●')).pack()
    tk.Label(window,text='Enter the current six-digit authenticator code to verify enrollment.\nDo not send any keys or codes in chat.',wraplength=700).pack(pady=20)
    otp=tk.Entry(window,show='●',width=15);otp.pack()
    def save():
        current=int(time.time())//30
        if not any(secrets.compare_digest(code(values['OWNER_TOTP_SECRET'],c),otp.get().strip()) for c in (current-1,current,current+1)):
            messagebox.showerror('Not saved','The authenticator code did not match. Please check the setup key and try again.');return
        if TARGET.is_symlink():raise RuntimeError('unsafe_secret_destination')
        os.umask(0o077)
        TARGET.write_text(''.join(k+'='+v+'\n' for k,v in values.items()))
        messagebox.showinfo('Enrollment verified','Saved privately. Return to Codex and say enrollment is complete. Keep the owner access key in your password manager.')
        window.destroy()
    tk.Button(window,text='Verify enrollment and save privately',command=save).pack(pady=20)
    window.mainloop()


if __name__=='__main__':main()
