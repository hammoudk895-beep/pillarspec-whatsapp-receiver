'use strict';
// Credential stays only in memory; never cookies, URLs, localStorage or telemetry.
let key = '';
const $ = id => document.getElementById(id);
async function api(path, body) {
  const response = await fetch(path, {
    method: body ? 'POST' : 'GET', cache: 'no-store', credentials: 'omit',
    headers: {Authorization: `Bearer ${key}`, 'Content-Type': 'application/json'},
    body: body ? JSON.stringify(body) : undefined
  });
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || 'Request failed');
  return value;
}
function text(parent, tag, value) {
  const el = document.createElement(tag);
  el.textContent = value;
  el.dir = 'auto';
  parent.append(el);
  return el;
}
async function refresh() {
  try {
    const result = await api('/api/review');
    $('messages').replaceChildren();
    $('notice').textContent = result.messages.length ? 'Latest 100 messages. Refresh to see updated delivery status.' : 'No messages received.';
    for (const item of result.messages) {
      const card = document.createElement('article');
      text(card, 'h3', `From ${item.sender} — ${item.state}`);
      text(card, 'p', item.text || 'Media or unsupported message: contact the customer through the approved business workflow.');
      if (item.draft) text(card, 'blockquote', item.draft);
      if (item.send_state) text(card, 'p', `Sending: ${item.send_state}. Delivery: ${item.delivery || 'unconfirmed'}.`);
      if (item.state === 'awaiting_human_approval') {
        for (const action of ['approve', 'reject']) {
          const button = text(card, 'button', action === 'approve' ? 'Approve exact reply' : 'Reject reply');
          button.addEventListener('click', async () => {
            button.disabled = true;
            try {
              const result = await api('/api/decision', {id: item.id, action, draft_hash: item.draft_hash});
              await refresh();
              $('notice').textContent = action === 'reject' ? 'Reply rejected.' : result.sending_enabled ? 'Approved and queued. Delivery is not yet confirmed.' : 'Approved and held. Sending is disabled.';
            } catch (error) {
              $('notice').textContent = error.message;
              button.disabled = false;
            }
          });
        }
      }
      $('messages').append(card, document.createElement('hr'));
    }
    $('refresh').hidden = $('logout').hidden = false;
  } catch (error) { $('notice').textContent = error.message; }
}
$('login').addEventListener('submit', event => {
  event.preventDefault();
  key = $('token').value;
  $('token').value = '';
  refresh();
});
$('refresh').addEventListener('click', refresh);
$('logout').addEventListener('click', () => {
  key = '';
  $('messages').replaceChildren();
  $('notice').textContent = 'Review queue locked.';
  $('refresh').hidden = $('logout').hidden = true;
});
