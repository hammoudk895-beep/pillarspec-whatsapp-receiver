'use strict';
document.getElementById('unlock').addEventListener('submit', async event => {
  event.preventDefault();
  const key = document.getElementById('owner-key');
  const code = document.getElementById('owner-code');
  const body = JSON.stringify({token:key.value,code:code.value});
  key.value = code.value = '';
  const status = document.getElementById('status');
  try {
    const result = await fetch('/api/owner/unlock',{method:'POST',credentials:'omit',cache:'no-store',
      headers:{'Content-Type':'application/json'},body});
    status.textContent = result.ok ? 'Unlocked for 30 minutes. Send your private account command on WhatsApp.' : 'Verification failed or setup is incomplete. Check your authenticator and owner key.';
  } catch (_) { status.textContent = 'Unable to reach Jarvis. Please try again.'; }
});
