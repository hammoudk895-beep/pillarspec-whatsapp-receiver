"""Prepare a newly mounted volume, then permanently drop root before serving."""
import os
from pathlib import Path

os.umask(0o077)
state = Path(os.environ.get('STATE_DIR', '/data'))
if not state.is_absolute() or state.is_symlink():
    raise SystemExit('state_directory_must_be_absolute_and_not_a_symlink')
state.mkdir(parents=True, exist_ok=True)
if os.getuid() == 0:
    os.chown(state, 10001, 10001)
    os.chmod(state, 0o700)
    os.setgroups([])
    os.setgid(10001)
    os.setuid(10001)
port = int(os.environ.get('PORT', '8080'))
if not 1 <= port <= 65535:
    raise SystemExit('invalid_port')
os.execvp('gunicorn', ['gunicorn', 'production:create_app()', '--bind', f'0.0.0.0:{port}',
    '--workers', '1', '--threads', '4', '--timeout', '70',
    '--access-logfile', '/dev/null', '--error-logfile', '-'])
