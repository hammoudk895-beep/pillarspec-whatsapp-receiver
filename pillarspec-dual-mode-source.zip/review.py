"""Local human decision records; never sends or approves on behalf of a human."""
import argparse
import getpass
import hashlib
import json
import time
import sys
import agent

def decide(db, message_id, decision, expected_hash, reviewer):
    if decision not in {'approve', 'reject'} or not reviewer.strip():
        raise ValueError('invalid_decision')
    db.execute('''CREATE TABLE IF NOT EXISTS review_decisions (
        id TEXT PRIMARY KEY, decision TEXT NOT NULL, draft_hash TEXT NOT NULL,
        reviewer TEXT NOT NULL, decided INTEGER NOT NULL)''')
    db.commit()
    db.execute('BEGIN IMMEDIATE')
    try:
        row = db.execute('SELECT state,draft FROM inbox WHERE id=?', (message_id,)).fetchone()
        if not row or row[0] != 'awaiting_human_approval' or not row[1]:
            raise ValueError('draft_not_awaiting_approval')
        actual = hashlib.sha256(row[1].encode()).hexdigest()
        if actual != expected_hash:
            raise ValueError('draft_changed_review_again')
        db.execute('INSERT INTO review_decisions VALUES(?,?,?,?,?)', (message_id, decision, actual, reviewer, int(time.time())))
        db.execute('UPDATE inbox SET state=? WHERE id=?', ('approved_not_sent' if decision == 'approve' else 'rejected', message_id))
        db.commit()
    except Exception:
        db.rollback()
        raise

def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    p = argparse.ArgumentParser(description='Human review only; no sending capability.')
    p.add_argument('message_id')
    args = p.parse_args()
    db = agent.connect()
    try:
        row = db.execute('SELECT sender,state,text,draft FROM inbox WHERE id=?', (args.message_id,)).fetchone()
        if not row or row[1] != 'awaiting_human_approval':
            raise SystemExit('No draft awaiting review for this message.')
        print(json.dumps({'recipient': row[0], 'customer_message': row[2], 'draft': row[3]}, ensure_ascii=False, indent=2))
        digest = hashlib.sha256(row[3].encode()).hexdigest()
        answer = input('Human reviewer: type approve or reject; anything else cancels: ').strip()
        if answer not in {'approve', 'reject'}:
            raise SystemExit('Cancelled.')
        decide(db, args.message_id, answer, digest, getpass.getuser())
        print('Decision recorded locally. Nothing sent.')
    finally:
        db.close()

if __name__ == '__main__':
    main()
