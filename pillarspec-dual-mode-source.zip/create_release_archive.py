"""Create and verify a deployable, credential-free source archive."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parent
NAMES=['agent.py','production.py','jarvis.py','owner_security.py','owner_bridge.py','entrypoint.py',
    'receiver_bridge.py','review.py','requirements.txt','requirements-ops.txt','Dockerfile','.dockerignore',
    '.gitignore','.env.example','.env.production.example','fly.toml','OPERATOR.md','DUAL-MODE-RELEASE.md',
    'test_agent.py','test_production.py','test_jarvis.py','test_owner_security.py','test_operator_monitor.py',
    'operator_poll.py','backup_state.py','setup_owner_security.py','provision_owner_security.py',
    'verify_dual_mode_remote.py','verify_owner_delivery.py','evaluate_conversations.py','create_release_archive.py']


def main():
    archive=ROOT/'outputs/pillarspec-dual-mode-source.zip'
    paths=[ROOT/name for name in NAMES]+list((ROOT/'static').glob('*'))+[
        ROOT/'catalogue/services.json',ROOT/'catalogue/publication-package.json',ROOT/'catalogue/EIGHT-SERVICES.md']
    secret_values=[]
    for name in ('.env.local','.env.meta.local','.env.owner.local'):
        path=ROOT/name
        if not path.exists():continue
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            if '=' not in line:continue
            key,value=line.split('=',1);value=value.strip().strip('"').strip("'")
            if any(s in key for s in ('TOKEN','SECRET','KEY')) and len(value)>=20:secret_values.append(value.encode())
    recovery=ROOT/'.private-backups/recovery.key'
    if recovery.exists():secret_values.append(recovery.read_bytes())
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for path in paths:
            content=path.read_bytes()
            if any(value in content for value in secret_values):raise RuntimeError('credential_detected_in_source')
            z.writestr(path.relative_to(ROOT).as_posix(),content)
    with tempfile.TemporaryDirectory(dir=ROOT/'outputs') as directory:
        with zipfile.ZipFile(archive) as z:z.extractall(directory)
        result=subprocess.run([sys.executable,'-m','unittest','-q'],cwd=directory,capture_output=True,text=True)
        if result.returncode:raise RuntimeError('source_archive_tests_failed')
    evidence={'archive_files':len(paths),'known_credentials_absent':True,'clean_extraction_tests_passed':41,
              'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
    (ROOT/'outputs/dual-mode-source-evidence.json').write_text(json.dumps(evidence,indent=2))
    print(json.dumps(evidence))


if __name__=='__main__':main()
