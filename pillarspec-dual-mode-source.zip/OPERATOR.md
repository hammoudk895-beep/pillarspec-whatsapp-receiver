# PillarSpec WhatsApp operation

## Security, monitoring and recovery update — 23 October 2026

Private business account commands are now protected by a separate owner access key and authenticator codes. Enrollment was verified in the local private dialog and the credentials were provisioned to Fly without displaying them. Unlock at https://pillarspec-whatsapp-agent.fly.dev/owner for 30 minutes, then send `/mail <search>`, `/calendar <date or query>`, or `/drive <document search>` from the authorized personal WhatsApp number. Ordinary Jarvis research remains available without the account unlock. Incorrect codes are rate limited, used codes cannot be replayed, and changing the configured owner revokes the unlock.

The selected account is hammoudk895@gmail.com. Reads use the existing Gmail, Business Google Calendar and Google Drive connections through a local Codex bridge; credentials are not copied from those connections to Fly. The bridge runs about every five minutes while this computer and Codex are available. It can search/read only, at most five relevant items. Sending, booking, editing, sharing and deleting are not available through it. Private account results are excluded from ordinary research history and the customer review API. Before running a command, check the relevant connector profile still matches the selected account.

The active Codex monitoring automation checks health, new human-review items, processing/send failures and backup age. It notifies in Codex only for actionable changes and stays quiet otherwise. It does not send WhatsApp or email alerts, so it does not depend on WhatsApp's 24-hour window or an approved template. Local monitoring cannot run while this computer/Codex is unavailable.

Backup verification: manual encrypted Fly snapshot `vs_323YLJRQJy74tzGao0Je` completed with five-day retention. Daily scheduled snapshots are enabled. In addition, `backup_state.py` creates consistent SQLite copies of both databases, downloads them over Fly's authenticated SSH connection, encrypts with AES-GCM locally and verifies restoration into disposable files with hashes and SQLite integrity checks. It never overwrites live databases. The automation requests a new encrypted backup and snapshot once the preceding local backup is more than 24 hours old. A full Fly snapshot-to-new-volume recovery has not been rehearsed; the verified restore is the independent database backup.

Encrypted backups and the recovery key are in ignored `.private-backups`, with Windows access restricted to the owner, task sandbox and system administrators. Keep a separate secure copy of `.private-backups/recovery.key` in your password manager or encrypted offline storage: losing this computer and the key loses access to these encrypted local backups. Never commit the key or populated env files. Host secrets must be restored separately; database backups do not contain them.

Local operations need `requirements-ops.txt`; the production container does not need that extra dependency. Current validation: 41 local tests, 11 deployed owner/security tests, 18 safe multilingual routing scenarios and sourced research in Arabic, English and French. One neutral Arabic inquiry legitimately permitted either fixed intake or approved catalogue wording; the evaluation records both acceptable routes.

Meta catalogue publication is still blocked: the correct business and existing catalogue are visible through Commerce Manager account navigation, but opening that exact catalogue redirects to permissions_needed and fails. Existing API credentials cannot access catalogue/products. Do not create a replacement catalogue or invent prices to work around this.

## Current dual-mode release — 23 October 2026

The active Fly service now routes Meta-signed messages from the owner-authorized personal number to private Jarvis mode. All other senders remain in PillarSpec customer mode. Owner messages use a separate `owner.sqlite3` database and are excluded from customer review APIs. Owner identity is the signed sender number, never a display name or a phone number written in message text. Anyone controlling the owner's WhatsApp account can use this mode; protect that account.

Simply message the PillarSpec business number from the authorized personal number to use Jarvis. No prefix is needed. Jarvis supports writing, questions, and sourced web research in Arabic, English or French. It has no business action tools, customer database access, shell access or authority to send messages to third parties. The real owner test received a signed delivered response. Private history is limited to six delivered/sent exchanges from the preceding 24 hours; owner records expire after 30 days. Send failures marked uncertain are never retried automatically.

`OWNER_WHATSAPP_NUMBER` in Fly configuration controls owner access. Removing it disables new owner processing; changing it also holds queued requests from the previous owner. Inspect protected `/api/ops` for aggregate owner states and delivery counts; private content is not exposed there. The shared customer-review credential does not grant an owner conversation API.

Eight service descriptions are loaded. Meta catalogue image publication is still blocked by Commerce Manager permissions/redirects and insufficient existing catalogue credential access. Original supplied artwork and descriptions are packaged locally. The sections below describe the customer review workflow; older references to seven services are superseded by this paragraph.

Review page: https://pillarspec-whatsapp-agent.fly.dev/

The page already opened in the owner's browser is authenticated. To open another session, privately copy `REVIEWER_TOKEN` from the ignored local `.env.meta.local` file into the page's password field. Do not send the value in chat, email, a URL or a screenshot. It is a shared bearer credential, not individual staff SSO; `PillarSpec owner` is the audit label for its actions.

Automatic routine intake is enabled. Greetings, ordinary inspection inquiries and supplied intake details can receive fixed reviewed wording in Arabic, English or French without a click. AI classification selects only route and language; model-written text is never sent automatically. Prices, quotes, contracts, payments, bookings, availability, technical/safety decisions, complaints, uncertain intent and routing failures are held. An unresolved human-review item keeps subsequent messages from that sender in review for the current 24-hour context. Check the customer request and exact displayed text. Approve only accurate replies; reject incorrect drafts. Quotes, scope commitments, contracts, bookings, availability, technical findings and safety statements need an authorized PillarSpec person. Seven owner-approved catalogue services are loaded.

Approving queues that exact draft; it is not delivery confirmation. With `SEND_ENABLED=false`, approved items are held. With sending enabled, the worker sends eligible approved items only within the free-form reply window and records the returned Meta message identifier. Delivery status appears after Meta's signed status event.

Never blindly retry `uncertain` sends: Meta may have accepted the message before its response was lost. An operator must check delivery evidence first. `window_closed`, `manual_review` and failed/rejected items require manual handling. This release does not send templates or attachments, edit drafts, or notify staff automatically.

Fly runs one instance with an encrypted 1GB persistent disk and automatic 5-day volume snapshots. Health checks run every 30 seconds. Confirm snapshots exist and test restoration before relying on them as a recovery plan; they are not an independently verified off-provider backup. No separate alert-recipient service is configured.

Customer records are removed after 30 days by an hourly job. Message-ID hashes remain for replay rejection. Provider data retention, backups and SQLite free space need separate deletion handling. Restrict the local credential file, host access and reviewer credential to authorized people.

Hosting authorization: up to US$10/month on Fly; this is not a provider-enforced billing cap. One 512MB shared-CPU instance and one 1GB disk are configured. OpenAI and WhatsApp usage are separate. Do not add replicas, managed databases or paid extensions without checking budget and changing the single-instance storage design.

The OpenAI key was previously provisioned with a reported 30-day expiry; verify its exact expiry privately in Platform and replace it before expiration. The previously exposed Meta app secret was rotated by the owner on 23 October 2026. The changed value was privately applied to Fly; new-secret signature validation and Meta app authentication passed. Future credential resets require owner action, followed by coordinated private host reconfiguration and verification. Do not print credentials.

Current completion limits and evidence are in `DEPLOYMENT.md`. In particular, a successful synthetic model test or Meta's dummy webhook is not proof that a real customer's message or outbound reply was delivered.

Automatic mode: AUTO_ROUTINE_ENABLED=true and SEND_ENABLED=true. Disable automatic routine processing by setting AUTO_ROUTINE_ENABLED=false and redeploying; future messages return to human approval. Existing queued sends need separate operational review. Automatic decisions carry audit label automatic_routine_v1 and state automatic_queued. No pending historical human-review drafts were automatically released.

Catalogue scope: seven services in catalogue/services.json. General catalogue questions may receive fixed multilingual descriptions automatically. Job-specific availability, quotes, contracts, bookings and technical decisions remain human. The eighth listed Bunker service awaits its full description. Original source screenshots are local evidence, not automatically sent to customers.
