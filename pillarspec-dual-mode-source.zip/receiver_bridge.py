"""Read the existing PillarSpec receiver feed into the local approval queue.

No sending, remote writes, or production configuration changes.
"""
import json
import os
import urllib.parse
import urllib.request
import agent

RECEIVER = 'https://pillarspec-whatsapp-receiver.onrender.com'
ACCOUNTS = {'1896543221723825', '1842772363415623'}
PHONE = '1367620946438403'

def import_page(db, page, after):
    events = page.get('events')
    cursor = page.get('next_cursor')
    if not isinstance(events, list) or not isinstance(cursor, int) or cursor < after:
        raise ValueError('invalid_receiver_page')
    # Validate the entire page before advancing any durable cursor.
    ids = [row.get('id') for row in events if isinstance(row, dict)]
    if len(ids) != len(events) or any(type(i) is not int or i <= after for i in ids) or ids != sorted(set(ids)):
        raise ValueError('invalid_receiver_event_ids')
    if cursor != (ids[-1] if ids else after):
        raise ValueError('invalid_receiver_cursor')
    for row in events:
        if row.get('kind') != 'message':
            continue
        payload = row.get('payload', {})
        if str(payload.get('account')) not in ACCOUNTS or payload.get('metadata', {}).get('phone_number_id') != PHONE:
            continue
        # Receiver validates signature and number; repeat identity checks at the boundary.
        agent.ingest(db, {'object': 'whatsapp_business_account', 'entry': [{
            'id': os.getenv('PILLARSPEC_ACCOUNT_ID', '1896543221723825'), 'changes': [{
                'field': 'messages', 'value': {'metadata': {'phone_number_id': PHONE},
                                             'messages': [payload.get('event', {})]}}]}]})
    # If interrupted before saving the cursor, event IDs safely deduplicate on replay.
    with db:
        db.execute('INSERT OR REPLACE INTO bridge_cursor(source,position) VALUES(?,?)', (RECEIVER, cursor))
    return cursor

def main():
    agent.load_env()
    token = os.getenv('INBOX_API_TOKEN')
    if not token:
        raise SystemExit('missing_inbox_api_token; configure securely, never paste it in chat')
    db = agent.connect()
    try:
        db.execute('CREATE TABLE IF NOT EXISTS bridge_cursor(source TEXT PRIMARY KEY, position INTEGER NOT NULL)')
        db.commit()
        row = db.execute('SELECT position FROM bridge_cursor WHERE source=?', (RECEIVER,)).fetchone()
        after = row[0] if row else 0
        request = urllib.request.Request(RECEIVER + '/api/events?' + urllib.parse.urlencode({'after': after}),
                                         headers={'Authorization': 'Bearer ' + token})
        # Reject redirects to prevent token forwarding to a different host.
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                return None
        with urllib.request.build_opener(NoRedirect).open(request, timeout=30) as response:
            body = response.read(8 * 1024 * 1024 + 1)
            if len(body) > 8 * 1024 * 1024:
                raise ValueError('receiver_page_too_large')
            page = json.loads(body)
        import_page(db, page, after)
        print('Receiver page imported into local review queue; no messages sent.')
    except Exception:
        raise SystemExit('receiver_import_failed; check connectivity, token and response structure securely') from None
    finally:
        db.close()

if __name__ == '__main__':
    main()
