import io
import json
import os
import tempfile
import time
import unittest
from unittest.mock import patch

import jarvis
import owner_bridge
import owner_security as security
import production


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.now=int(time.time())
        self.secret='GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ'
        self.env=patch.dict(os.environ,{'STATE_DIR':self.temp.name,'OWNER_WHATSAPP_NUMBER':'96176868315',
            'OWNER_TOTP_SECRET':self.secret,'OWNER_CONTROL_TOKEN':'c'*40,'OWNER_BRIDGE_TOKEN':'b'*40,
            'SEND_ENABLED':'true','REVIEWER_TOKEN':'r'*40})
        self.env.start()

    def tearDown(self):
        self.env.stop();self.temp.cleanup()

    def unlock(self):
        return security.unlock('c'*40,security.code(self.secret,self.now//30),self.now)

    def message(self,mid='private',text='/mail subject:meeting'):
        return {'id':mid,'from':jarvis.owner(),'timestamp':str(self.now),'type':'text','text':{'body':text}}

    def request(self,path,body=None,token=''):
        raw=json.dumps(body or {}).encode();result=[]
        env={'REQUEST_METHOD':'POST' if body is not None else 'GET','PATH_INFO':path,
             'CONTENT_LENGTH':str(len(raw)),'wsgi.input':io.BytesIO(raw),'HTTP_AUTHORIZATION':token}
        data=b''.join(production.App()(env,lambda s,h:result.append(s)))
        return result[0],json.loads(data)

    def test_totp_known_vector_replay_expiration_and_revocation(self):
        self.assertEqual(security.code(self.secret,1),'287082')
        self.assertFalse(security.unlock('wrong','287082',59))
        self.assertTrue(self.unlock())
        self.assertFalse(self.unlock())
        self.assertTrue(security.unlocked(self.now))
        self.assertFalse(security.unlocked(self.now+1801))
        with patch.dict(os.environ,{'OWNER_WHATSAPP_NUMBER':'96170000000'}):
            self.assertFalse(security.unlocked(self.now))

    def test_rate_limit_after_five_wrong_codes(self):
        for _ in range(5):self.assertFalse(security.unlock('c'*40,'invalid',self.now))
        self.assertFalse(self.unlock())
        later=self.now+301
        self.assertTrue(security.unlock('c'*40,security.code(self.secret,later//30),later))

    def test_bridge_credential_is_independent_and_step_up_required(self):
        self.assertTrue(self.request('/api/owner/bridge',token='Bearer '+'r'*40)[0].startswith('401'))
        self.assertEqual(self.request('/api/owner/bridge',token='Bearer '+'b'*40)[1],{'tasks':[]})
        self.assertTrue(self.request('/api/owner/unlock',{'token':'r'*40,'code':'000000'})[0].startswith('401'))
        jarvis.accept(self.message(),self.now)
        sent=[]
        jarvis.tick(lambda *args:sent.append(args) or 'meta',lambda *_:self.fail('Account request reached model'))
        self.assertIn('unlock',sent[0][1].lower())
        self.assertEqual(owner_bridge.pending(),[])

    def test_bridge_result_private_dedup_and_not_reused_for_web_research(self):
        self.assertTrue(self.unlock())
        jarvis.accept(self.message(),self.now)
        sent=[]
        jarvis.tick(lambda *a:sent.append(a) or 'meta',lambda *_:self.fail('Bridge reached model'))
        self.assertEqual(sent,[])
        self.assertEqual(len(owner_bridge.pending()),1)
        owner_bridge.complete('private','PRIVATE EMAIL CONTENT')
        with self.assertRaises(ValueError):owner_bridge.complete('private','duplicate')
        jarvis.tick(lambda *a:sent.append(a) or 'meta')
        self.assertIn('PRIVATE EMAIL CONTENT',sent[0][1])
        jarvis.accept(self.message('research','Why is the sky blue?'),self.now)
        history=[]
        def generate(text,previous):history.extend(previous);return 'Research answer'
        jarvis.tick(lambda *a:'meta2',generate)
        self.assertNotIn('PRIVATE EMAIL CONTENT',json.dumps(history))
        db=production.connect()
        self.assertEqual(db.execute('SELECT COUNT(*) FROM inbox').fetchone()[0],0);db.close()

    def test_privileged_result_waits_for_unlock_and_customer_cannot_access(self):
        self.unlock();jarvis.accept(self.message(),self.now)
        jarvis.tick(lambda *_:self.fail('Premature send'))
        owner_bridge.complete('private','private content')
        with patch('owner_security.unlocked',return_value=False):
            jarvis.tick(lambda *_:self.fail('Locked result sent'))
        status,result=self.request('/api/review',token='Bearer '+'r'*40)
        self.assertTrue(status.startswith('200'));self.assertEqual(result['messages'],[])
