"""Independent owner control credential plus replay-protected authenticator codes."""
import base64
import hashlib
import hmac
import os
import struct
import time

import jarvis


def configured():
    return all(len(os.getenv(k, '')) >= 32 for k in ('OWNER_TOTP_SECRET', 'OWNER_CONTROL_TOKEN', 'OWNER_BRIDGE_TOKEN'))


def code(secret, counter):
    key = base64.b32decode(secret + '=' * (-len(secret) % 8), casefold=True)
    raw = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
    offset = raw[-1] & 15
    return str((struct.unpack('>I', raw[offset:offset+4])[0] & 0x7fffffff) % 1000000).zfill(6)


def schema(db):
    db.execute('''CREATE TABLE IF NOT EXISTS owner_auth(singleton INTEGER PRIMARY KEY CHECK(singleton=1),
        counter INTEGER NOT NULL, until INTEGER NOT NULL, failures INTEGER NOT NULL,
        blocked_until INTEGER NOT NULL, fingerprint TEXT NOT NULL)''')
    db.execute("INSERT OR IGNORE INTO owner_auth VALUES(1,-1,0,0,0,'')")


def fingerprint():
    return hashlib.sha256((os.getenv('OWNER_TOTP_SECRET', '') + ':' + (jarvis.owner() or '')).encode()).hexdigest()


def unlocked(now=None):
    if not configured():
        return False
    db = jarvis.connect()
    try:
        with db:
            schema(db)
            row = db.execute('SELECT * FROM owner_auth WHERE singleton=1').fetchone()
            return row['fingerprint'] == fingerprint() and row['until'] > (int(time.time()) if now is None else now)
    finally:
        db.close()


def unlock(token, otp, now=None):
    now = int(time.time()) if now is None else now
    if not configured() or not isinstance(token, str) or not hmac.compare_digest(token, os.environ['OWNER_CONTROL_TOKEN']):
        return False
    db = jarvis.connect()
    try:
        db.execute('BEGIN IMMEDIATE')
        schema(db)
        row = db.execute('SELECT * FROM owner_auth WHERE singleton=1').fetchone()
        if row['blocked_until'] > now:
            db.commit()
            return False
        last = row['counter'] if row['fingerprint'] == fingerprint() else -1
        matched = next((counter for counter in (now//30-1, now//30, now//30+1)
                        if counter > last and isinstance(otp, str) and hmac.compare_digest(code(os.environ['OWNER_TOTP_SECRET'], counter), otp)), None)
        if matched is None:
            failures = row['failures'] + 1
            db.execute('UPDATE owner_auth SET failures=?,blocked_until=? WHERE singleton=1',
                       (0 if failures >= 5 else failures, now + 300 if failures >= 5 else 0))
            db.commit()
            return False
        db.execute('UPDATE owner_auth SET counter=?,until=?,failures=0,blocked_until=0,fingerprint=? WHERE singleton=1',
                   (matched, now + 1800, fingerprint()))
        db.commit()
        return True
    finally:
        db.close()


def bridge_authorized(header):
    token = os.getenv('OWNER_BRIDGE_TOKEN', '')
    return len(token) >= 32 and isinstance(header, str) and hmac.compare_digest(header, 'Bearer ' + token)
