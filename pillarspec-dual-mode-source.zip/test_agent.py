import hashlib
import hmac
import json
import tempfile
import threading
import urllib.request
import urllib.error
import os
from unittest.mock import patch
from http.server import HTTPServer
import unittest
from pathlib import Path
import agent
import receiver_bridge
import review

def event(text='hello', phone='1367620946438403', account='1896543221723825', kind='text'):
    return {'object': 'whatsapp_business_account', 'entry': [{'id': account, 'changes': [
        {'field': 'messages', 'value': {'metadata': {'phone_number_id': phone}, 'messages': [
            {'id': 'synthetic-1', 'from': 'synthetic-customer', 'type': kind, 'text': {'body': text}}]}}]}]}

class Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = agent.connect(Path(self.temp.name) / 'test.db')

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def test_signature(self):
        raw = b'example'
        sig = 'sha256=' + hmac.new(b'secret', raw, hashlib.sha256).hexdigest()
        self.assertTrue(agent.signed(raw, sig, 'secret'))
        self.assertFalse(agent.signed(raw+b'x', sig, 'secret'))
        self.assertFalse(agent.signed(raw, sig, ''))

    def test_tenant_isolation(self):
        self.assertEqual(agent.ingest(self.db, event(phone='other')), 0)
        self.assertEqual(agent.ingest(self.db, event(account='other')), 0)

    def test_deduplication_and_approval(self):
        self.assertEqual(agent.ingest(self.db, event()), 1)
        self.assertEqual(agent.ingest(self.db, event()), 0)
        self.assertTrue(agent.work(self.db, lambda _: 'draft only'))
        self.assertFalse(agent.work(self.db, lambda _: self.fail('duplicate generation')))
        self.assertEqual(self.db.execute('SELECT state FROM inbox').fetchone()[0], 'awaiting_human_approval')

    def test_failure_is_closed(self):
        agent.ingest(self.db, event())
        def fail(_):
            raise RuntimeError('SECRET should not persist')
        agent.work(self.db, fail)
        self.assertEqual(self.db.execute('SELECT state,error FROM inbox').fetchone(), ('manual_review', 'draft_generation_failed'))

    def test_media_manual_review(self):
        agent.ingest(self.db, event(kind='image'))
        self.assertFalse(agent.work(self.db))
        self.assertEqual(self.db.execute('SELECT state FROM inbox').fetchone()[0], 'manual_review')

    def test_three_languages_survive_queue(self):
        for text in ['English inspection', 'فحص الموقع', 'Inspection du bâtiment']:
            self.db.execute('DELETE FROM inbox')
            self.db.commit()
            agent.ingest(self.db, event(text))
            agent.work(self.db, lambda t: t)
            self.assertEqual(self.db.execute('SELECT draft FROM inbox').fetchone()[0], text)

    def test_http_webhook_to_review(self):
        path = Path(self.temp.name) / 'http.db'
        original_connect = agent.connect
        server = HTTPServer(('127.0.0.1', 0), agent.Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        with patch.dict(os.environ, {'META_APP_SECRET': 'synthetic-secret', 'META_VERIFY_TOKEN': 'synthetic-token'}), patch.object(agent, 'connect', lambda: original_connect(path)):
            thread.start()
            base = 'http://127.0.0.1:' + str(server.server_port)
            try:
                with urllib.request.urlopen(base + '/webhook?hub.mode=subscribe&hub.verify_token=synthetic-token&hub.challenge=123') as response:
                    self.assertEqual(response.read(), b'123')
                raw = json.dumps(event('Bonjour, inspection demandée')).encode()
                request = urllib.request.Request(base+'/webhook', data=raw)
                with self.assertRaises(urllib.error.HTTPError) as denied:
                    urllib.request.urlopen(request)
                self.assertEqual(denied.exception.code, 403)
                request.add_header('X-Hub-Signature-256', 'sha256='+hmac.new(b'synthetic-secret', raw, hashlib.sha256).hexdigest())
                for _ in range(2):
                    with urllib.request.urlopen(request) as response:
                        self.assertEqual(response.status, 200)
                db = original_connect(path)
                try:
                    agent.work(db, lambda _: 'Brouillon pour validation humaine.')
                    self.assertEqual(db.execute('SELECT count(*) FROM inbox').fetchone()[0], 1)
                    self.assertEqual(db.execute('SELECT state FROM inbox').fetchone()[0], 'awaiting_human_approval')
                finally:
                    db.close()
            finally:
                server.shutdown()
                server.server_close()
                thread.join()

    def test_existing_receiver_bridge(self):
        self.db.execute('CREATE TABLE bridge_cursor(source TEXT PRIMARY KEY, position INTEGER NOT NULL)')
        self.db.commit()
        payload = {'account': '1842772363415623', 'metadata': {'phone_number_id': '1367620946438403'},
                   'event': {'id': 'bridge-1', 'from': 'synthetic', 'type': 'text', 'text': {'body': 'مرحبا'}}}
        page = {'events': [{'id': 1, 'kind': 'message', 'payload': payload}], 'next_cursor': 1}
        self.assertEqual(receiver_bridge.import_page(self.db, page, 0), 1)
        receiver_bridge.import_page(self.db, page, 0)  # replay after interruption
        self.assertEqual(self.db.execute('SELECT count(*) FROM inbox').fetchone()[0], 1)
        agent.work(self.db, lambda text: text)
        self.assertEqual(self.db.execute('SELECT state,draft FROM inbox').fetchone(), ('awaiting_human_approval', 'مرحبا'))
        with self.assertRaises(ValueError):
            receiver_bridge.import_page(self.db, {'events': [], 'next_cursor': 99}, 1)
        payload['metadata']['phone_number_id'] = 'other'
        receiver_bridge.import_page(self.db, {'events': [{'id': 2, 'kind': 'message', 'payload': payload}], 'next_cursor': 2}, 1)
        self.assertEqual(self.db.execute('SELECT count(*) FROM inbox').fetchone()[0], 1)

    def test_human_decision_binds_exact_draft(self):
        agent.ingest(self.db, event())
        agent.work(self.db, lambda _: 'Reviewed text')
        with self.assertRaises(ValueError):
            review.decide(self.db, 'synthetic-1', 'approve', 'stale-hash', 'test-reviewer')
        self.assertEqual(self.db.execute('SELECT state FROM inbox').fetchone()[0], 'awaiting_human_approval')
        digest = hashlib.sha256(b'Reviewed text').hexdigest()
        review.decide(self.db, 'synthetic-1', 'approve', digest, 'test-reviewer')
        self.assertEqual(self.db.execute('SELECT state FROM inbox').fetchone()[0], 'approved_not_sent')
        with self.assertRaises(ValueError):
            review.decide(self.db, 'synthetic-1', 'approve', digest, 'test-reviewer')

    def test_retention_removes_expired_customer_data_and_decision(self):
        agent.ingest(self.db, event())
        agent.work(self.db, lambda _: 'Reviewed text')
        review.decide(self.db, 'synthetic-1', 'reject', hashlib.sha256(b'Reviewed text').hexdigest(), 'test-reviewer')
        self.db.execute('UPDATE inbox SET received=0')
        self.db.commit()
        self.assertEqual(agent.purge_expired(self.db), 1)
        self.assertEqual(self.db.execute('SELECT count(*) FROM review_decisions').fetchone()[0], 0)
        with self.assertRaises(ValueError):
            agent.purge_expired(self.db, 0)

if __name__ == '__main__':
    unittest.main()
