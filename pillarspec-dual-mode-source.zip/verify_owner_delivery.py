"""Retain safe correlated proof of the real owner test, without private content."""
import base64
import json
from pathlib import Path
import shlex
import subprocess

root = Path(__file__).resolve().parent
script = '''import hashlib,json,jarvis,production
db=jarvis.connect()
row=db.execute("SELECT * FROM requests ORDER BY received DESC LIMIT 1").fetchone()
safe={'owner_request_present':bool(row)}
if row:
 customer=production.connect()
 safe.update({'inbound_id_sha256':hashlib.sha256(row['id'].encode()).hexdigest(),
  'state':row['state'],'delivery':row['delivery'],
  'matches_controlled_research':all(s in row['text'].lower() for s in ('mars','nasa')),
  'reply_contains_https_source':'https://' in (row['reply'] or ''),
  'private_request_absent_from_customer_queue':customer.execute('SELECT COUNT(*) FROM inbox WHERE id=?',(row['id'],)).fetchone()[0]==0})
 customer.close()
db.close()
print('SAFE_EVIDENCE='+json.dumps(safe))
'''
command = 'python -c ' + shlex.quote("import base64;exec(base64.b64decode('" + base64.b64encode(script.encode()).decode() + "'))")
result = subprocess.run([str(root/'.tools/fly/bin/flyctl.exe'),'ssh','console','--app',
    'pillarspec-whatsapp-agent','--command',command],capture_output=True,text=True)
line = next((s.split('SAFE_EVIDENCE=',1)[1] for s in result.stdout.splitlines() if s.startswith('SAFE_EVIDENCE=')), None)
if line:
    safe=json.loads(line)
    (root/'outputs/owner-real-delivery-evidence.json').write_text(json.dumps(safe,indent=2))
    print(json.dumps(safe))
else:
    print(json.dumps({'safe_verification_failed':True,'exit_code':result.returncode}))
raise SystemExit(result.returncode)
